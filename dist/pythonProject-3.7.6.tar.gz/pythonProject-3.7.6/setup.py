from setuptools import setup

setup(
    name='pythonProject',
    version='3.7.6',
    packages=['talk', 'roboter', 'roboter.views', 'roboter.models', 'roboter.controller'],
    url='',
    license='free',
    author='Banri Yasui',
    author_email='s1270210@u-aizu.ac.jp',
    description='robot recommend restaurant to user'
)
