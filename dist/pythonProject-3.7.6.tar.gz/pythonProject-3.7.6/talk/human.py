def scream():
    print("AAAAAAAAAAA")

def main():
    print(__name__)
    print("Nooooo")

if __name__ == "__main__":
    main()